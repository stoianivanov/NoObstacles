/* globals $ */
/* eslint-env node, dirigible */

var ioLib = require('io');
var entityLib = require('entity');

// create entity by parsing JSON object from request body
exports.createBus_stop = function() {
    var input = ioLib.read($.getRequest().getInputStream());
    var requestBody = JSON.parse(input);
    var connection = $.getDatasource().getConnection();
    try {
        var sql = "INSERT INTO BUS_STOP (";
        sql += "ID";
        sql += ",";
        sql += "LATITUDE";
        sql += ",";
        sql += "LONGITUDE";
        sql += ",";
        sql += "BUSNUMBER";
        sql += ",";
        sql += "METAINFO";
        sql += ") VALUES ("; 
        sql += "?";
        sql += ",";
        sql += "?";
        sql += ",";
        sql += "?";
        sql += ",";
        sql += "?";
        sql += ",";
        sql += "?";
        sql += ")";

        var statement = connection.prepareStatement(sql);
        var i = 0;
        var id = $.getDatabaseUtils().getNext('BUS_STOP_ID');
        statement.setInt(++i, id);
        statement.setDouble(++i, requestBody.latitude);
        statement.setDouble(++i, requestBody.longitude);
        statement.setInt(++i, requestBody.busnumber);
        statement.setString(++i, requestBody.metainfo);
        statement.executeUpdate();
		$.getResponse().getWriter().println(id);
        return id;
    } catch(e) {
        var errorCode = $.getResponse().SC_BAD_REQUEST;
        entityLib.printError(errorCode, errorCode, e.message, sql);
    } finally {
        connection.close();
    }
    return -1;
};

// read single entity by id and print as JSON object to response
exports.readBus_stopEntity = function(id) {
    var connection = $.getDatasource().getConnection();
    try {
        var result;
        var sql = "SELECT * FROM BUS_STOP WHERE " + exports.pkToSQL();
        var statement = connection.prepareStatement(sql);
        statement.setInt(1, id);
        
        var resultSet = statement.executeQuery();
        if (resultSet.next()) {
            result = createEntity(resultSet);
        } else {
        	entityLib.printError($.getResponse().SC_NOT_FOUND, 1, "Record with id: " + id + " does not exist.", sql);
        }
        var jsonResponse = JSON.stringify(result, null, 2);
        $.getResponse().getWriter().println(jsonResponse);
    } catch(e){
        var errorCode = $.getResponse().SC_BAD_REQUEST;
        entityLib.printError(errorCode, errorCode, e.message, sql);
    } finally {
        connection.close();
    }
};

// read all entities and print them as JSON array to response
exports.readBus_stopList = function(limit, offset, sort, desc) {
    var connection = $.getDatasource().getConnection();
    try {
        var result = [];
        var sql = "SELECT ";
        if (limit !== null && offset !== null) {
            sql += " " + $.getDatabaseUtils().createTopAndStart(limit, offset);
        }
        sql += " * FROM BUS_STOP";
        if (sort !== null) {
            sql += " ORDER BY " + sort;
        }
        if (sort !== null && desc !== null) {
            sql += " DESC ";
        }
        if (limit !== null && offset !== null) {
            sql += " " + $.getDatabaseUtils().createLimitAndOffset(limit, offset);
        }
        var statement = connection.prepareStatement(sql);
        var resultSet = statement.executeQuery();
        while (resultSet.next()) {
            result.push(createEntity(resultSet));
        }
        var jsonResponse = JSON.stringify(result, null, 2);
        $.getResponse().getWriter().println(jsonResponse);
    } catch(e){
        var errorCode = $.getResponse().SC_BAD_REQUEST;
        entityLib.printError(errorCode, errorCode, e.message, sql);
    } finally {
        connection.close();
    }
};

//create entity as JSON object from ResultSet current Row
function createEntity(resultSet) {
    var result = {};
	result.id = resultSet.getInt("ID");
    result.latitude = resultSet.getDouble("LATITUDE");
    result.longitude = resultSet.getDouble("LONGITUDE");
	result.busnumber = resultSet.getInt("BUSNUMBER");
    result.metainfo = resultSet.getString("METAINFO");
    return result;
}

function convertToDateString(date) {
    var fullYear = date.getFullYear();
    var month = date.getMonth() < 10 ? "0" + date.getMonth() : date.getMonth();
    var dateOfMonth = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
    return fullYear + "/" + month + "/" + dateOfMonth;
}

// update entity by id
exports.updateBus_stop = function() {
    var input = ioLib.read($.getRequest().getInputStream());
    var responseBody = JSON.parse(input);
    var connection = $.getDatasource().getConnection();
    try {
        var sql = "UPDATE BUS_STOP SET ";
        sql += "LATITUDE = ?";
        sql += ",";
        sql += "LONGITUDE = ?";
        sql += ",";
        sql += "BUSNUMBER = ?";
        sql += ",";
        sql += "METAINFO = ?";
        sql += " WHERE ID = ?";
        var statement = connection.prepareStatement(sql);
        var i = 0;
        statement.setDouble(++i, responseBody.latitude);
        statement.setDouble(++i, responseBody.longitude);
        statement.setInt(++i, responseBody.busnumber);
        statement.setString(++i, responseBody.metainfo);
        var id = responseBody.id;
        statement.setInt(++i, id);
        statement.executeUpdate();
		$.getResponse().getWriter().println(id);
    } catch(e){
        var errorCode = $.getResponse().SC_BAD_REQUEST;
        entityLib.printError(errorCode, errorCode, e.message, sql);
    } finally {
        connection.close();
    }
};

// delete entity
exports.deleteBus_stop = function(id) {
    var connection = $.getDatasource().getConnection();
    try {
    	var sql = "DELETE FROM BUS_STOP WHERE " + exports.pkToSQL();
        var statement = connection.prepareStatement(sql);
        statement.setString(1, id);
        statement.executeUpdate();
        $.getResponse().getWriter().println(id);
    } catch(e){
        var errorCode = $.getResponse().SC_BAD_REQUEST;
        entityLib.printError(errorCode, errorCode, e.message, sql);
    } finally {
        connection.close();
    }
};

exports.countBus_stop = function() {
    var count = 0;
    var connection = $.getDatasource().getConnection();
    try {
    	var sql = 'SELECT COUNT(*) FROM BUS_STOP';
        var statement = connection.createStatement();
        var rs = statement.executeQuery(sql);
        if (rs.next()) {
            count = rs.getInt(1);
        }
    } catch(e){
        var errorCode = $.getResponse().SC_BAD_REQUEST;
        entityLib.printError(errorCode, errorCode, e.message, sql);
    } finally {
        connection.close();
    }
    $.getResponse().getWriter().println(count);
};

exports.metadataBus_stop = function() {
	var entityMetadata = {
		name: 'bus_stop',
		type: 'object',
		properties: []
	};
	
	var propertyid = {
		name: 'id',
		type: 'integer',
	key: 'true',
	required: 'true'
	};
    entityMetadata.properties.push(propertyid);

	var propertylatitude = {
		name: 'latitude',
		type: 'double'
	};
    entityMetadata.properties.push(propertylatitude);

	var propertylongitude = {
		name: 'longitude',
		type: 'double'
	};
    entityMetadata.properties.push(propertylongitude);

	var propertybusnumber = {
		name: 'busnumber',
		type: 'integer'
	};
    entityMetadata.properties.push(propertybusnumber);

	var propertymetainfo = {
		name: 'metainfo',
		type: 'string'
	};
    entityMetadata.properties.push(propertymetainfo);


	$.getResponse().getWriter().println(JSON.stringify(entityMetadata));
};

exports.getPrimaryKeys = function() {
    var result = [];
    var i = 0;
    result[i++] = 'ID';
    if (result === 0) {
        throw $.getExceptionUtils().createException("There is no primary key");
    } else if(result.length > 1) {
        throw $.getExceptionUtils().createException("More than one Primary Key is not supported.");
    }
    return result;
};

exports.getPrimaryKey = function() {
	return exports.getPrimaryKeys()[0].toLowerCase();
};

exports.pkToSQL = function() {
    var pks = exports.getPrimaryKeys();
    return pks[0] + " = ?";
};